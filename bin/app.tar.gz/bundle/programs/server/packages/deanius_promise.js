(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['deanius:promise'] = {};

})();
