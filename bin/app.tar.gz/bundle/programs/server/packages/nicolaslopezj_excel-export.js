(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;

/* Package-scope variables */
var searchObject, Excel;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/nicolaslopezj_excel-export/packages/nicolaslopezj_excel-export.js             //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/nicolaslopezj:excel-export/lib.js                                       //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
searchObject = function(object, key, selectFirstIfIsArray) {                        // 1
  key = key.split('.');                                                             // 2
                                                                                    // 3
  try {                                                                             // 4
    for (var i = 0; i < key.length; i++) {                                          // 5
      if (selectFirstIfIsArray && object.length && object.length > 0) {             // 6
        object = object[0];                                                         // 7
      }                                                                             // 8
      if (key[i] in object) {                                                       // 9
        object = object[key[i]];                                                    // 10
      } else {                                                                      // 11
        return null;                                                                // 12
      }                                                                             // 13
    }                                                                               // 14
  } catch(error) {                                                                  // 15
    return null;                                                                    // 16
  }                                                                                 // 17
                                                                                    // 18
  return object || null;                                                            // 19
}                                                                                   // 20
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/nicolaslopezj:excel-export/excel.js                                     //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
Excel = {};                                                                         // 1
Excel.lib = Npm.require('excel-export');                                            // 2
                                                                                    // 3
Excel.getColumns = function(fields, data) {                                         // 4
  var rows = [];                                                                    // 5
                                                                                    // 6
  _.each(data, function(item) {                                                     // 7
    var row = [];                                                                   // 8
    _.each(fields, function(field, index) {                                         // 9
      var value = searchObject(item, field.key) || null;                            // 10
      value = _.isFunction(field.transform) ? field.transform(value, item) : value; // 11
      row[index] = value                                                            // 12
    });                                                                             // 13
    rows.push(row);                                                                 // 14
  });                                                                               // 15
                                                                                    // 16
  return rows;                                                                      // 17
};                                                                                  // 18
                                                                                    // 19
                                                                                    // 20
Excel.export = function(title, fields, data) {                                      // 21
  check(title, String);                                                             // 22
  check(fields, [{                                                                  // 23
    key: String,                                                                    // 24
    title: String,                                                                  // 25
    type: Match.Optional(String),                                                   // 26
    width: Match.Optional(Number),                                                  // 27
    transform: Match.Optional(Function)                                             // 28
  }]);                                                                              // 29
  check(data, [Match.Any]);                                                         // 30
                                                                                    // 31
  var rows = this.getColumns(fields, data);                                         // 32
                                                                                    // 33
  var excel = {};                                                                   // 34
  excel.cols = fields.map(function(field) {                                         // 35
    return {                                                                        // 36
      caption: field.title,                                                         // 37
      type: field.type || 'string',                                                 // 38
      width: field.width || 28.7109375                                              // 39
    };                                                                              // 40
  });                                                                               // 41
                                                                                    // 42
  excel.rows = rows;                                                                // 43
  return Excel.lib.execute(excel);                                                  // 44
}                                                                                   // 45
                                                                                    // 46
//////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['nicolaslopezj:excel-export'] = {}, {
  Excel: Excel
});

})();
