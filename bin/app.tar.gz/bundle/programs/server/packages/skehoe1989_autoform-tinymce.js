(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['skehoe1989:autoform-tinymce'] = {};

})();
