(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var Tabular;

var require = meteorInstall({"node_modules":{"meteor":{"aldeed:tabular":{"server":{"main.js":["meteor/meteor","meteor/check","meteor/underscore","../common/Tabular",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/aldeed_tabular/server/main.js                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor = void 0;                                                                                               // 1
module.importSync("meteor/meteor", {                                                                               // 1
  Meteor: function (v) {                                                                                           // 1
    Meteor = v;                                                                                                    // 1
  }                                                                                                                // 1
}, 0);                                                                                                             // 1
var check = void 0,                                                                                                // 1
    Match = void 0;                                                                                                // 1
module.importSync("meteor/check", {                                                                                // 1
  check: function (v) {                                                                                            // 1
    check = v;                                                                                                     // 1
  },                                                                                                               // 1
  Match: function (v) {                                                                                            // 1
    Match = v;                                                                                                     // 1
  }                                                                                                                // 1
}, 1);                                                                                                             // 1
                                                                                                                   //
var _ = void 0;                                                                                                    // 1
                                                                                                                   //
module.importSync("meteor/underscore", {                                                                           // 1
  _: function (v) {                                                                                                // 1
    _ = v;                                                                                                         // 1
  }                                                                                                                // 1
}, 2);                                                                                                             // 1
var Tabular = void 0;                                                                                              // 1
module.importSync("../common/Tabular", {                                                                           // 1
  "default": function (v) {                                                                                        // 1
    Tabular = v;                                                                                                   // 1
  }                                                                                                                // 1
}, 3);                                                                                                             // 1
/*                                                                                                                 // 6
 * These are the two publications used by TabularTable.                                                            //
 *                                                                                                                 //
 * The genericPub one can be overridden by supplying a `pub`                                                       //
 * property with a different publication name. This publication                                                    //
 * is given only the list of ids and requested fields. You may                                                     //
 * want to override it if you need to publish documents from                                                       //
 * related collections along with the table collection documents.                                                  //
 *                                                                                                                 //
 * The getInfo one runs first and handles all the complex logic                                                    //
 * required by this package, so that you don't have to duplicate                                                   //
 * this logic when overriding the genericPub function.                                                             //
 *                                                                                                                 //
 * Having two publications also allows fine-grained control of                                                     //
 * reactivity on the client.                                                                                       //
 */Meteor.publish('tabular_genericPub', function (tableName, ids, fields) {                                        //
  check(tableName, String);                                                                                        // 24
  check(ids, Array);                                                                                               // 25
  check(fields, Match.Optional(Object));                                                                           // 26
  var table = Tabular.tablesByName[tableName];                                                                     // 28
                                                                                                                   //
  if (!table) {                                                                                                    // 29
    // We throw an error in the other pub, so no need to throw one here                                            // 30
    this.ready();                                                                                                  // 31
    return;                                                                                                        // 32
  } // Check security. We call this in both publications.                                                          // 33
                                                                                                                   //
                                                                                                                   //
  if (typeof table.allow === 'function' && !table.allow(this.userId, fields)) {                                    // 36
    this.ready();                                                                                                  // 37
    return;                                                                                                        // 38
  } // Check security for fields. We call this only in this publication                                            // 39
                                                                                                                   //
                                                                                                                   //
  if (typeof table.allowFields === 'function' && !table.allowFields(this.userId, fields)) {                        // 42
    this.ready();                                                                                                  // 43
    return;                                                                                                        // 44
  }                                                                                                                // 45
                                                                                                                   //
  return table.collection.find({                                                                                   // 47
    _id: {                                                                                                         // 47
      $in: ids                                                                                                     // 47
    }                                                                                                              // 47
  }, {                                                                                                             // 47
    fields: fields                                                                                                 // 47
  });                                                                                                              // 47
});                                                                                                                // 48
Meteor.publish('tabular_getInfo', function (tableName, selector, sort, skip, limit) {                              // 50
  var _this = this;                                                                                                // 50
                                                                                                                   //
  check(tableName, String);                                                                                        // 51
  check(selector, Match.Optional(Match.OneOf(Object, null)));                                                      // 52
  check(sort, Match.Optional(Match.OneOf(Array, null)));                                                           // 53
  check(skip, Number);                                                                                             // 54
  check(limit, Match.Optional(Match.OneOf(Number, null)));                                                         // 55
  var table = Tabular.tablesByName[tableName];                                                                     // 57
                                                                                                                   //
  if (!table) {                                                                                                    // 58
    throw new Error("No TabularTable defined with the name \"" + tableName + "\". Make sure you are defining your TabularTable in common code.");
  } // Check security. We call this in both publications.                                                          // 60
  // Even though we're only publishing _ids and counts                                                             // 63
  // from this function, with sensitive data, there is                                                             // 64
  // a chance someone could do a query and learn something                                                         // 65
  // just based on whether a result is found or not.                                                               // 66
                                                                                                                   //
                                                                                                                   //
  if (typeof table.allow === 'function' && !table.allow(this.userId)) {                                            // 67
    this.ready();                                                                                                  // 68
    return;                                                                                                        // 69
  }                                                                                                                // 70
                                                                                                                   //
  selector = selector || {}; // Allow the user to modify the selector before we use it                             // 72
                                                                                                                   //
  if (typeof table.changeSelector === 'function') {                                                                // 75
    selector = table.changeSelector(selector, this.userId);                                                        // 76
  } // Apply the server side selector specified in the tabular                                                     // 77
  // table constructor. Both must be met, so we join                                                               // 80
  // them using $and, allowing both selectors to have                                                              // 81
  // the same keys.                                                                                                // 82
                                                                                                                   //
                                                                                                                   //
  if (typeof table.selector === 'function') {                                                                      // 83
    var tableSelector = table.selector(this.userId);                                                               // 84
                                                                                                                   //
    if (_.isEmpty(selector)) {                                                                                     // 85
      selector = tableSelector;                                                                                    // 86
    } else {                                                                                                       // 87
      selector = {                                                                                                 // 88
        $and: [tableSelector, selector]                                                                            // 88
      };                                                                                                           // 88
    }                                                                                                              // 89
  }                                                                                                                // 90
                                                                                                                   //
  var findOptions = {                                                                                              // 92
    skip: skip,                                                                                                    // 93
    fields: {                                                                                                      // 94
      _id: 1                                                                                                       // 94
    }                                                                                                              // 94
  }; // `limit` may be `null`                                                                                      // 92
                                                                                                                   //
  if (limit > 0) {                                                                                                 // 98
    findOptions.limit = limit;                                                                                     // 99
  } // `sort` may be `null`                                                                                        // 100
                                                                                                                   //
                                                                                                                   //
  if (_.isArray(sort)) {                                                                                           // 103
    findOptions.sort = sort;                                                                                       // 104
  }                                                                                                                // 105
                                                                                                                   //
  var filteredCursor = table.collection.find(selector, findOptions);                                               // 107
  var filteredRecordIds = filteredCursor.map(function (doc) {                                                      // 109
    return doc._id;                                                                                                // 109
  }); // If we are not going to count for real, in order to improve performance, then we will fake                 // 109
  // the count to ensure the Next button is always available.                                                      // 112
                                                                                                                   //
  var fakeCount = filteredRecordIds.length + skip + 1;                                                             // 113
  var countCursor = table.collection.find(selector, {                                                              // 115
    fields: {                                                                                                      // 115
      _id: 1                                                                                                       // 115
    }                                                                                                              // 115
  });                                                                                                              // 115
  var recordReady = false;                                                                                         // 117
                                                                                                                   //
  var updateRecords = function () {                                                                                // 118
    var currentCount = void 0;                                                                                     // 119
                                                                                                                   //
    if (!table.skipCount) {                                                                                        // 120
      if (typeof table.alternativeCount === 'function') {                                                          // 121
        currentCount = table.alternativeCount(selector);                                                           // 122
      } else {                                                                                                     // 123
        currentCount = countCursor.count();                                                                        // 124
      }                                                                                                            // 125
    } // From https://datatables.net/manual/server-side                                                            // 126
    // recordsTotal: Total records, before filtering (i.e. the total number of records in the database)            // 129
    // recordsFiltered: Total records, after filtering (i.e. the total number of records after filtering has been applied - not just the number of records being returned for this page of data).
                                                                                                                   //
                                                                                                                   //
    var record = {                                                                                                 // 132
      ids: filteredRecordIds,                                                                                      // 133
      // count() will give us the updated total count                                                              // 134
      // every time. It does not take the find options                                                             // 135
      // limit into account.                                                                                       // 136
      recordsTotal: table.skipCount ? fakeCount : currentCount,                                                    // 137
      recordsFiltered: table.skipCount ? fakeCount : currentCount                                                  // 138
    };                                                                                                             // 132
                                                                                                                   //
    if (recordReady) {                                                                                             // 141
      //console.log('changed', tableName, record);                                                                 // 142
      _this.changed('tabular_records', tableName, record);                                                         // 143
    } else {                                                                                                       // 144
      //console.log('added', tableName, record);                                                                   // 145
      _this.added('tabular_records', tableName, record);                                                           // 146
                                                                                                                   //
      recordReady = true;                                                                                          // 147
    }                                                                                                              // 148
  };                                                                                                               // 149
                                                                                                                   //
  if (table.throttleRefresh) {                                                                                     // 151
    // Why Meteor.bindEnvironment? See https://github.com/aldeed/meteor-tabular/issues/278#issuecomment-217318112  // 152
    updateRecords = _.throttle(Meteor.bindEnvironment(updateRecords), table.throttleRefresh);                      // 153
  }                                                                                                                // 154
                                                                                                                   //
  updateRecords();                                                                                                 // 156
  this.ready(); // Handle docs being added or removed from the result set.                                         // 158
                                                                                                                   //
  var initializing = true;                                                                                         // 161
  var handle = filteredCursor.observeChanges({                                                                     // 162
    added: function (id) {                                                                                         // 163
      if (initializing) return; //console.log('ADDED');                                                            // 164
                                                                                                                   //
      filteredRecordIds.push(id);                                                                                  // 167
      updateRecords();                                                                                             // 168
    },                                                                                                             // 169
    removed: function (id) {                                                                                       // 170
      //console.log('REMOVED');                                                                                    // 171
      // _.findWhere is used to support Mongo ObjectIDs                                                            // 172
      filteredRecordIds = _.without(filteredRecordIds, _.findWhere(filteredRecordIds, id));                        // 173
      updateRecords();                                                                                             // 174
    }                                                                                                              // 175
  });                                                                                                              // 162
  initializing = false; // It is too inefficient to use an observe without any limits to track count perfectly     // 177
  // accurately when, for example, the selector is {} and there are a million documents.                           // 180
  // Instead we will update the count every 10 seconds, in addition to whenever the limited                        // 181
  // result set changes.                                                                                           // 182
                                                                                                                   //
  var interval = Meteor.setInterval(updateRecords, 10000); // Stop observing the cursors when client unsubs.       // 183
  // Stopping a subscription automatically takes                                                                   // 186
  // care of sending the client any removed messages.                                                              // 187
                                                                                                                   //
  this.onStop(function () {                                                                                        // 188
    Meteor.clearInterval(interval);                                                                                // 189
    handle.stop();                                                                                                 // 190
  });                                                                                                              // 191
});                                                                                                                // 192
module.export("default", exports.default = Tabular);                                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"common":{"Tabular.js":["babel-runtime/helpers/classCallCheck","meteor/meteor","meteor/mongo",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/aldeed_tabular/common/Tabular.js                                                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                            //
                                                                                                                   //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                   //
                                                                                                                   //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                  //
                                                                                                                   //
var Meteor = void 0;                                                                                               // 1
module.importSync("meteor/meteor", {                                                                               // 1
  Meteor: function (v) {                                                                                           // 1
    Meteor = v;                                                                                                    // 1
  }                                                                                                                // 1
}, 0);                                                                                                             // 1
var Mongo = void 0;                                                                                                // 1
module.importSync("meteor/mongo", {                                                                                // 1
  Mongo: function (v) {                                                                                            // 1
    Mongo = v;                                                                                                     // 1
  }                                                                                                                // 1
}, 1);                                                                                                             // 1
var Tabular = {};                                                                                                  // 4
Tabular.tablesByName = {};                                                                                         // 6
                                                                                                                   //
Tabular.Table = function () {                                                                                      // 8
  function _class(options) {                                                                                       // 9
    (0, _classCallCheck3.default)(this, _class);                                                                   // 9
    if (!options) throw new Error('Tabular.Table options argument is required');                                   // 10
    if (!options.name) throw new Error('Tabular.Table options must specify name');                                 // 11
    if (!options.columns) throw new Error('Tabular.Table options must specify columns');                           // 12
                                                                                                                   //
    if (!(options.collection instanceof Mongo.Collection || options.collection instanceof Mongo.constructor // Fix: error if `collection: Meteor.users`
    )) {                                                                                                           // 13
      throw new Error('Tabular.Table options must specify collection');                                            // 16
    }                                                                                                              // 17
                                                                                                                   //
    this.name = options.name;                                                                                      // 19
    this.collection = options.collection;                                                                          // 20
    this.pub = options.pub || 'tabular_genericPub'; // By default we use core `Meteor.subscribe`, but you can pass
    // a subscription manager like `sub: new SubsManager({cacheLimit: 20, expireIn: 3})`                           // 25
                                                                                                                   //
    this.sub = options.sub || Meteor;                                                                              // 26
    this.onUnload = options.onUnload;                                                                              // 28
    this.allow = options.allow;                                                                                    // 29
    this.allowFields = options.allowFields;                                                                        // 30
    this.changeSelector = options.changeSelector;                                                                  // 31
    this.throttleRefresh = options.throttleRefresh;                                                                // 32
    this.alternativeCount = options.alternativeCount;                                                              // 33
    this.skipCount = options.skipCount;                                                                            // 34
                                                                                                                   //
    if (_.isArray(options.extraFields)) {                                                                          // 36
      var fields = {};                                                                                             // 37
                                                                                                                   //
      _.each(options.extraFields, function (fieldName) {                                                           // 38
        fields[fieldName] = 1;                                                                                     // 39
      });                                                                                                          // 40
                                                                                                                   //
      this.extraFields = fields;                                                                                   // 41
    }                                                                                                              // 42
                                                                                                                   //
    this.selector = options.selector;                                                                              // 44
    this.options = _.omit(options, 'collection', 'pub', 'sub', 'onUnload', 'allow', 'allowFields', 'changeSelector', 'throttleRefresh', 'extraFields', 'alternativeCount', 'skipCount', 'name', 'selector');
    Tabular.tablesByName[this.name] = this;                                                                        // 63
  }                                                                                                                // 64
                                                                                                                   //
  return _class;                                                                                                   // 8
}();                                                                                                               // 8
                                                                                                                   //
module.export("default", exports.default = Tabular);                                                               // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/aldeed:tabular/server/main.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['aldeed:tabular'] = exports, {
  Tabular: Tabular
});

})();

//# sourceMappingURL=aldeed_tabular.js.map
